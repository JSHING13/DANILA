# flor_amarilla
codigo de la flor amarilla para dedicar UwU
esta medio chafita porque solo cambien las cosas que necesitaba pero funciona bien 💙
